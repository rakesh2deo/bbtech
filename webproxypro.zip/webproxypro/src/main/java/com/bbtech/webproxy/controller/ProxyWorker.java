package com.bbtech.webproxy.controller;

import org.springframework.core.io.Resource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.util.Random;
import java.util.function.Supplier;

public class ProxyWorker implements Supplier<ResponseEntity<Resource>> {
    public static int defaultRetries = 3;
    public static long defaultWaitTimeInMills = 20000;
    private int numberOfRetries = defaultRetries;
    private int numberOfTriesLeft = defaultRetries;
    private long timeToWait = defaultWaitTimeInMills;
    private final Random random = new Random();

    private final HttpEntity<Object> httpEntity;
    private final String url;
    private RestTemplate template;

    public ProxyWorker(RestTemplate template,
                       HttpEntity<Object> httpEntity,
                       String url) {
        this.httpEntity = httpEntity;
        this.template = template;
        this.url = url;
    }

    @Override
    public ResponseEntity<Resource> get() {
        return this.eb();
    }

    private ResponseEntity<Resource> eb() {
        ResponseEntity<Resource> response = null;
        int index = 1;
        while (null == response) {
            response = upstreamCall();
            if (null == response) {
                System.out.println("Doing retry. Retry Count : " + index++ + " for : "+url);
                if(numberOfRetries == 0){
                    System.out.println("Retry exhusted.");
                    return null;
                }
                errorOccured();
            } else {
                System.out.println("Upstream call is successful for : "+url);
                return response;
            }
        }
        return null;
    }

    private ResponseEntity<Resource> upstreamCall() {
        try{
            ResponseEntity<Resource> response = template.exchange(this.url, HttpMethod.POST, this.httpEntity,
                    Resource.class);
            if (response.getStatusCode() == HttpStatus.CREATED) {
                return response;
            } else {
                return null;
            }
        }catch (Exception ex){
            ex.printStackTrace();
            return null;
        }
    }

    public void errorOccured() {
        numberOfTriesLeft--;
        waitUntilNextTry();
        timeToWait += random.nextInt(1000);
    }

    private void waitUntilNextTry() {
        try {
            Thread.sleep(timeToWait);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}