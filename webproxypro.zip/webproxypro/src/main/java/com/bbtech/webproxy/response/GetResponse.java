package com.bbtech.webproxy.response;

public class GetResponse {

    public int totalGetRequest;
    public long maxCallTime;
    public long minCallTime;
    public double avgCallTime;

    public  GetResponse(){

    }
    public int getTotalGetRequest() {
        return totalGetRequest;
    }
    public void setTotalGetRequest(int totalGetRequest) {
        this.totalGetRequest = totalGetRequest;
    }
    public long getMaxCallTime() {
        return maxCallTime;
    }
    public void setMaxCallTime(long maxCallTime) {
        this.maxCallTime = maxCallTime;
    }
    public long getMinCallTime() {
        return minCallTime;
    }
    public void setMinCallTime(long minCallTime) {
        this.minCallTime = minCallTime;
    }
    public double getAvgCallTime() {
        return avgCallTime;
    }
    public void setAvgCallTime(double avgCallTime) {
        this.avgCallTime = avgCallTime;
    }


}
