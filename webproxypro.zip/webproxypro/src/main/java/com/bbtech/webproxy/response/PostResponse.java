package com.bbtech.webproxy.response;

public class PostResponse {

    public int totalRequestPost;
    public long maxCallTimePost;
    public long minCallTimePost;
    public double avgCallTimePost;

    public PostResponse(){

    }

    public int getTotalRequestPost() {
        return totalRequestPost;
    }
    public void setTotalRequestPost(int totalRequestPost) {
        this.totalRequestPost = totalRequestPost;
    }
    public long getMaxCallTimePost() {
        return maxCallTimePost;
    }
    public void setMaxCallTimePost(long maxCallTimePost) {
        this.maxCallTimePost = maxCallTimePost;
    }
    public long getMinCallTimePost() {
        return minCallTimePost;
    }
    public void setMinCallTimePost(long minCallTimePost) {
        this.minCallTimePost = minCallTimePost;
    }
    public double getAvgCallTimePost() {
        return avgCallTimePost;
    }
    public void setAvgCallTimePost(double avgCallTimePost) {
        this.avgCallTimePost = avgCallTimePost;
    }
}
